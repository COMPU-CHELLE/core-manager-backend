import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // ===============================
  // 🔥 CREAR PLAN
  // ===============================
  const plan1 = await prisma.plan.create({
    data: {
      name: 'Básico',
      price: 200000,
      maxUsers: 5,
      maxAssets: 50,
    },
  });

  const plan2 = await prisma.plan.create({
    data: {
      name: 'Premium',
      price: 500000,
      maxUsers: 10,
      maxAssets: 100,
    },
  });

  // ===============================
  // 🔥 CREAR EMPRESA DEMO
  // ===============================
  const company = await prisma.company.create({
    data: {
      name: 'Compuchelle S.A.S',
      nit: '1045689957',
      planId: plan1.id,
    },
  });

  // ===============================
  // 🔥 CREAR PERMISOS
  // ===============================
  const modules = [
    'companies',
    'users',
    'roles',
    'branches',
    'plans',
    'employees',
    'assets',
    'asset_assignments',
    'maintenances',
    'tickets',
    'invoices',
    'credentials',
    'tasks',
    'dashboard',
    'audit',
  ];

  const actions = [
    { action: 'create', name: 'crear' },
    { action: 'read', name: 'ver' },
    { action: 'update', name: 'actualizar' },
    { action: 'delete', name: 'eliminar' },
    { action: 'softdelete', name: 'eliminar (lógico)' },
  ];

  for (const module of modules) {
    for (const { action, name } of actions) {
      await prisma.permission.upsert({
        where: {
          module_action: {
            module,
            action,
          },
        },
        update: {},
        create: {
          name,
          code: `${module}.${action}`,
          module,
          action,
        },
      });
    }
  }

  // ===============================
  // 🔥 PERMISO ESPECIAL: revelar credenciales cifradas
  // (no aplica a los demás módulos, por eso va aparte del loop)
  // ===============================
  await prisma.permission.upsert({
    where: {
      module_action: {
        module: 'credentials',
        action: 'reveal',
      },
    },
    update: {},
    create: {
      name: 'revelar clave',
      code: 'credentials.reveal',
      module: 'credentials',
      action: 'reveal',
    },
  });

  const allPermissions = await prisma.permission.findMany();

  // ===============================
  // 🔥 ROL GLOBAL SOPORTE
  // ===============================
  const superRole = await prisma.role.create({
    data: {
      code: 'SOPORTE',
      name: 'Soporte Sistema',
      isGlobal: true,
    },
  });

  // ===============================
  // 🔥 ROL ADMIN EMPRESA
  // ===============================
  const adminRole = await prisma.role.create({
    data: {
      code: 'ADMIN',
      name: 'Administrador Empresa',
      companyId: company.id,
      isGlobal: false,
    },
  });

  // Asignar todos los permisos a ambos roles
  for (const permission of allPermissions) {
    await prisma.rolePermission.create({
      data: {
        roleId: superRole.id,
        permissionId: permission.id,
      },
    });

    await prisma.rolePermission.create({
      data: {
        roleId: adminRole.id,
        permissionId: permission.id,
      },
    });
  }

  const soportePass = await bcrypt.hash('Soporte123', 10);
  const adminPass = await bcrypt.hash('Admin123', 10);

  // ===============================
  // 🔥 USUARIO SOPORTE
  // ===============================
  await prisma.user.create({
    data: {
      code: 'SOPORTE',
      name: 'Soporte General',
      email: 'soporte@system.com',
      password: soportePass,
      companyId: company.id, // 👈 mientras no hagas company opcional
      roleId: superRole.id,
    },
  });

  // ===============================
  // 🔥 ADMIN EMPRESA
  // ===============================
  await prisma.user.create({
    data: {
      code: 'ADMIN',
      name: 'Administrador',
      email: 'admin@compuchelle.com',
      password: adminPass,
      companyId: company.id,
      roleId: adminRole.id,
    },
  });

  const branch = await prisma.branch.create({
    data: {
      code: 'MAIN',
      name: 'Sucursal Principal',
      address: 'Calle 123 #45-67',
      email: 'principal@compuchelle.com',
      companyId: company.id,
    },
  });

  await prisma.employee.createMany({
    data: [
      {
        name: 'Juan Pérez',
        position: 'Desarrollador',
        email: 'juan@compuchelle.com',
        companyId: company.id,
        branchId: branch.id,
      },
      {
        name: 'María Gómez',
        position: 'Soporte TI',
        email: 'maria@compuchelle.com',
        companyId: company.id,
        branchId: branch.id,
      },
    ],
  });

  const laptop = await prisma.asset.create({
    data: {
      name: 'Laptop Dell',
      type: 'Laptop',
      brand: 'Dell',
      model: 'Latitude 5420',
      serial: 'DL-123456',
      purchaseDate: new Date('2024-01-10'),
      cost: 1350000,
      companyId: company.id,
      branchId: branch.id,
      detail: {
        create: {
          ram_type: 'DDR4',
          ram_capacity: '16GB',
          hdd_type: 'SSD',
          hdd_capacity: '512GB',
          pro_type: 'Intel',
          pro_detail: 'i5 11th Gen',
          mbr_type: 'Dell',
          mbr_detail: 'OEM',
          gra_type: 'Intel',
          gra_detail: 'UHD Graphics',
          monitor: '14"',
          mon_detail: 'Full HD',
          keyboard: 'QWERTY',
          key_detail: 'Retroiluminado',
          mouse: 'Externo',
          mou_detail: 'USB',
        },
      },
    },
  });

  await prisma.assetAssignment.create({
    data: {
      assetId: laptop.id,
      employeeId: 1, // Juan Pérez (primer empleado)
    },
  });

  await prisma.ticket.createMany({
    data: [
      {
        title: 'No enciende el equipo',
        status: 'OPEN',
        companyId: company.id,
      },
      {
        title: 'Problema con correo',
        status: 'CLOSED',
        companyId: company.id,
      },
    ],
  });

  await prisma.invoice.create({
    data: {
      number: 'FAC-001',
      provider: 'Proveedor TI',
      date: new Date(),
      category: 'Hardware',
      companyId: company.id,
      branchId: branch.id,
      items: {
        create: [
          {
            description: 'Laptop Dell',
            quantity: 1,
            unitPrice: 1350000,
            tax: 19,
            total: 1606500,
          },
        ],
      },
    },
  });

  await prisma.task.createMany({
    data: [
      {
        title: 'Configurar Laptop Nueva',
        description: 'Configuracion Equipo Nuevo Asesor',
        status: 'OPEN',
        priority: 'HIGH',
        companyId: company.id,
        createdById: 2,
      },
      {
        title: 'Actualizar antivirus',
        description: 'Equipo Gerencia Caducidad',
        status: 'DONE',
        priority: 'MEDIUM',
        companyId: company.id,
        createdById: 2,
      },
    ],
  });

  // ===============================
  // 🔥 AUDIT LOGS DE PRUEBA (SOLO DEMO)
  // ===============================

  const adminUser = await prisma.user.findFirst({
    where: { email: 'admin@compuchelle.com' },
  });

  if (adminUser) {
    await prisma.auditLog.createMany({
      data: [
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'LOGIN',
          entity: 'auth',
          method: 'POST',
          path: '/auth/login',
          ip: '127.0.0.1',
        },
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'CREATE',
          entity: 'asset',
          entityId: laptop.id,
          method: 'POST',
          path: '/assets',
          ip: '127.0.0.1',
        },
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'ASSIGN',
          entity: 'asset_assignment',
          entityId: 1,
          method: 'POST',
          path: '/asset-assignments',
          ip: '127.0.0.1',
        },
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'CREATE',
          entity: 'ticket',
          entityId: 1,
          method: 'POST',
          path: '/tickets',
          ip: '127.0.0.1',
        },
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'CREATE',
          entity: 'invoice',
          entityId: 1,
          method: 'POST',
          path: '/invoices',
          ip: '127.0.0.1',
        },
        {
          userId: adminUser.id,
          companyId: company.id,
          action: 'CREATE',
          entity: 'task',
          entityId: 1,
          method: 'POST',
          path: '/tasks',
          ip: '127.0.0.1',
        },
      ],
    });
  }

  console.log('✅ Seed completo listo');

  // =====================================================
  // 🔥 SEGUNDA EMPRESA - FERRESUMINISTRO SAS
  // =====================================================

  const company2 = await prisma.company.create({
    data: {
      name: 'Ferresuministro S.A.S',
      nit: '900456321-1',
      planId: plan2.id,
    },
  });

  // ---------------------------
  // 🔥 ROL ADMIN EMPRESA 2
  // ---------------------------
  const adminRole2 = await prisma.role.create({
    data: {
      code: 'ADMIN2',
      name: 'Administrador Ferresuministro',
      companyId: company2.id,
      isGlobal: false,
    },
  });

  // Asignar todos los permisos al admin de empresa 2
  for (const permission of allPermissions) {
    await prisma.rolePermission.create({
      data: {
        roleId: adminRole2.id,
        permissionId: permission.id,
      },
    });
  }

  // ---------------------------
  // 🔥 USUARIO ADMIN EMPRESA 2
  // ---------------------------
  const admin2Pass = await bcrypt.hash('Admin123', 10);

  const adminUser2 = await prisma.user.create({
    data: {
      code: 'ADMIN2',
      name: 'Admin Ferresuministro',
      email: 'admin@ferresuministro.com',
      password: admin2Pass,
      companyId: company2.id,
      roleId: adminRole2.id,
    },
  });

  // ---------------------------
  // 🔥 SUCURSAL EMPRESA 2
  // ---------------------------
  const branch2 = await prisma.branch.create({
    data: {
      code: 'MAIN2',
      name: 'Sucursal Central Ferre',
      address: 'Carrera 45 #12-89',
      email: 'central@ferresuministro.com',
      companyId: company2.id,
    },
  });

  // ---------------------------
  // 🔥 EMPLEADOS EMPRESA 2
  // ---------------------------
  await prisma.employee.createMany({
    data: [
      {
        name: 'Carlos Ramírez',
        position: 'Bodeguero',
        email: 'carlos@ferresuministro.com',
        companyId: company2.id,
        branchId: branch2.id,
      },
      {
        name: 'Laura Martínez',
        position: 'Contadora',
        email: 'laura@ferresuministro.com',
        companyId: company2.id,
        branchId: branch2.id,
      },
    ],
  });

  // ---------------------------
  // 🔥 ACTIVO EMPRESA 2
  // ---------------------------
  await prisma.asset.create({
    data: {
      name: 'Impresora HP',
      type: 'Impresora',
      brand: 'HP',
      model: 'LaserJet Pro M404',
      serial: 'HP-987654',
      purchaseDate: new Date('2024-03-15'),
      cost: 950000,
      companyId: company2.id,
      branchId: branch2.id,
    },
  });

  // ---------------------------
  // 🔥 TICKETS EMPRESA 2
  // ---------------------------
  await prisma.ticket.createMany({
    data: [
      {
        title: 'Impresora no imprime',
        status: 'OPEN',
        companyId: company2.id,
      },
      {
        title: 'Actualización sistema contable',
        status: 'IN_PROGRESS',
        companyId: company2.id,
      },
    ],
  });

  // ---------------------------
  // 🔥 TAREAS EMPRESA 2
  // ---------------------------
  await prisma.task.createMany({
    data: [
      {
        title: 'Revisar inventario',
        description: 'Revision Stock Bodega 1',
        status: 'OPEN',
        priority: 'HIGH',
        companyId: company2.id,
        createdById: 3,
      },
      {
        title: 'Instalar drivers impresora',
        status: 'DONE',
        description: 'Instalar Impresora nueva area de ventas',
        priority: 'MEDIUM',
        companyId: company2.id,
        createdById: 3,
      },
    ],
  });

  // ---------------------------
  // 🔥 AUDIT LOG EMPRESA 2
  // ---------------------------
  await prisma.auditLog.create({
    data: {
      userId: adminUser2.id,
      companyId: company2.id,
      action: 'LOGIN',
      entity: 'auth',
      method: 'POST',
      path: '/auth/login',
      ip: '127.0.0.1',
    },
  });
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });
